﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Botao : MonoBehaviour {

    public Animator Animar;
    public Transform Player;
    public GameObject LuzOn;

    bool onOff = false;

	void Start ()
    {
       
        LuzOn.GetComponent<Light>().enabled = false;
            Animar.GetComponent<Animator>().enabled = true;
	}
	
	void Update () 
    {
        if(Input.GetMouseButtonDown(0))
        {
            onOff = !onOff;
            acenderApagar(onOff);
            Animar.SetBool("ativarBotao", true);
        }
        if (Input.GetMouseButtonUp(0))
            Animar.SetBool("ativarBotao", !Animar);
	}
  
    void acenderApagar(bool onOff)
    {
        if (onOff)
        {
            LuzOn.GetComponent<Light>().enabled = true;
            Behaviour halo = (Behaviour)GetComponent("Halo");
        }
        else
        {
            LuzOn.GetComponent<Light>().enabled = false;

        }
    }

}
